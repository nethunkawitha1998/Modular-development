package fruitjuiceservicepublisher;

public class ServicePublishImpl implements ServicePublish {
	
	@Override
	public void CalculateAmount(char drink_name, int drink_type, int quantity, float amount) {
		
		if(drink_type == 1)
			System.out.println("Total Payable Amount For the Order On Medium Sized Drinks is Rs."+(300*quantity)+"\n");
		
		if(drink_type == 2)
			System.out.println("Total Payable Amount For the Order On Large Sized Drinks is Rs."+(500*quantity)+"\n");
		
		if(drink_type == 3)
			System.out.println("Total Payable Amount For the Order On Extra-large Sized Drinks is Rs."+(700*quantity)+"\n");
		
		
	}
}
