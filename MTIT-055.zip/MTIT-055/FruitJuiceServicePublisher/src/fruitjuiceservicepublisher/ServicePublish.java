package fruitjuiceservicepublisher;

public interface ServicePublish {

	public void CalculateAmount(char drink_name, int drink_type, int quantity, float amount);
	
}
 