package fruitjuiceservicesubscriber;

import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import fruitjuiceservicepublisher.ServicePublish;

public class ServiceActivator implements BundleActivator {

	ServiceReference serviceReference;
	char drink_name;
	int drink_type; 
	int quantity;
	float amount;
	String yes;
	
	
	
	public void start(BundleContext context) throws Exception {
		
		
		serviceReference = context.getServiceReference(ServicePublish.class.getName());
		ServicePublish servicePublish = (ServicePublish) context.getService(serviceReference);
		
		System.out.println("This is Fruit Juice Reservation Service Subscriber Start Service Subscriber \n");
		
		System.out.println("Do You Want To Order A Fruit Juice ? If Yes, Press y/Y");
		System.out.print("Answer: ");
		Scanner inputs = new Scanner(System.in);
	    yes=inputs.next();
	    
	    System.out.println("");
	    
	    do {
		  	  
	    	 System.out.println(" --- FRUIT JUICE ORDER SERVICE --- \n");			  			     
	    	 
			 System.out.println("For Medium Sized Drink  -> Press 1");
			 System.out.println("For Large Sized Drink -> Press 2");
			 System.out.println("For Extra-Large Size Drink  -> Press 3 ");
			 
			 System.out.println("");
			 
			 System.out.print("Enter the Drink Size: ");
			 int drink_type = inputs.nextInt();
			 
		     System.out.println("");
		     
		     System.out.println("Enter the Quantity of Drinks : ");
		     int quantity = inputs.nextInt();

		     
		     servicePublish.CalculateAmount(drink_name, drink_type, quantity, amount);
			 
			 System.out.println("Do you want to order again ?");
			 System.out.print("Answer: ");
			 yes = inputs.next();
		} while (yes.equals("y")|| yes.equals("Y"));
				
			}

	public void stop(BundleContext context) throws Exception {
		System.out.println("good bye!!!");
		context.ungetService(serviceReference);
	}

}
